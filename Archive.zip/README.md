# Telegram web-client

<i>Pure js without bloatware</i>

API is based on <a href="https://github.com/zhukov/webogram">webogram</a> and <a href="https://github.com/sunriselink/TelegramApi">TelegramApi</a> repo,
also some code is taken from <a href="https://github.com/zerobias/telegram-mtproto">mtproto</a> JS implementation.

### Launch

```bash
yarn install
yarn start
```
