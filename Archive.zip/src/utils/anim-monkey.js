import idle from '../static/animation/monkey_idle.json';
import peek from '../static/animation/monkey_peek.json';
import close_peek from '../static/animation/monkey_close_peek.json';
import track from '../static/animation/monkey_track.json';

export { idle, peek, close_peek, track };
