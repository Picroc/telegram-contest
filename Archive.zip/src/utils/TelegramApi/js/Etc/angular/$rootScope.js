export default function $rootScopeModule() {
    return window;
}
