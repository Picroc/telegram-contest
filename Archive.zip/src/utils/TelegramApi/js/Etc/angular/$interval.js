export default function $interval() {
    setInterval(...arguments);
}
