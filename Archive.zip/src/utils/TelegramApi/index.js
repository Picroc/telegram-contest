import TelegramApi from './TelegramApi';
export default TelegramApi;